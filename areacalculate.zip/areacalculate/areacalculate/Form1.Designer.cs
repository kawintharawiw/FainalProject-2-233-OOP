﻿namespace areacalculate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnsquare = new System.Windows.Forms.Button();
            this.btnrectangle = new System.Windows.Forms.Button();
            this.btncircular = new System.Windows.Forms.Button();
            this.btntriangler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnsquare
            // 
            this.btnsquare.Location = new System.Drawing.Point(55, 91);
            this.btnsquare.Name = "btnsquare";
            this.btnsquare.Size = new System.Drawing.Size(75, 23);
            this.btnsquare.TabIndex = 0;
            this.btnsquare.Text = "สี่เหลี่ยมผืนผ้า ";
            this.btnsquare.UseVisualStyleBackColor = true;
            this.btnsquare.Click += new System.EventHandler(this.btnsquare_Click);
            // 
            // btnrectangle
            // 
            this.btnrectangle.Location = new System.Drawing.Point(159, 91);
            this.btnrectangle.Name = "btnrectangle";
            this.btnrectangle.Size = new System.Drawing.Size(75, 23);
            this.btnrectangle.TabIndex = 1;
            this.btnrectangle.Text = "สี่เหลี่ยมจัตุรัส";
            this.btnrectangle.UseVisualStyleBackColor = true;
            this.btnrectangle.Click += new System.EventHandler(this.btnrectangle_Click);
            // 
            // btncircular
            // 
            this.btncircular.Location = new System.Drawing.Point(55, 148);
            this.btncircular.Name = "btncircular";
            this.btncircular.Size = new System.Drawing.Size(75, 23);
            this.btncircular.TabIndex = 2;
            this.btncircular.Text = "วงกลม";
            this.btncircular.UseVisualStyleBackColor = true;
            this.btncircular.Click += new System.EventHandler(this.btncircular_Click);
            // 
            // btntriangler
            // 
            this.btntriangler.Location = new System.Drawing.Point(159, 148);
            this.btntriangler.Name = "btntriangler";
            this.btntriangler.Size = new System.Drawing.Size(75, 23);
            this.btntriangler.TabIndex = 3;
            this.btntriangler.Text = "สามเหลี่ยม";
            this.btntriangler.UseVisualStyleBackColor = true;
            this.btntriangler.Click += new System.EventHandler(this.btntriangler_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btntriangler);
            this.Controls.Add(this.btncircular);
            this.Controls.Add(this.btnrectangle);
            this.Controls.Add(this.btnsquare);
            this.Name = "Form1";
            this.Text = "areacalculate";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnsquare;
        private System.Windows.Forms.Button btnrectangle;
        private System.Windows.Forms.Button btncircular;
        private System.Windows.Forms.Button btntriangler;
    }
}

