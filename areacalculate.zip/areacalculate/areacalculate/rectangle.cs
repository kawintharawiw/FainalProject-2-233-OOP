﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace areacalculate
{
    public partial class Rectangle : Form
    {
        public Rectangle()
        {
            InitializeComponent();
        }
         
        private void btnCal_Click(object sender, EventArgs e)
        {
            areacalculateExtension rec = new areacalculateExtension();
            double Width = Convert.ToDouble(txtW.Text);
            double Long = Convert.ToDouble(txtL.Text);

            double result = 0;

            result = rec.Rectangleresult(Width, Long);

            RectangleResult res = new RectangleResult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
