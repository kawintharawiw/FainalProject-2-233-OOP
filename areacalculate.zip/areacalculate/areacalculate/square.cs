﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace areacalculate
{
    public partial class square : Form
    {
        public square()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            areacalculateExtension squ = new areacalculateExtension();
            double D = Convert.ToInt32(txtD.Text);
            double result = 0;

            result = squ.Squareresult(D);

            squareresult res = new squareresult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
