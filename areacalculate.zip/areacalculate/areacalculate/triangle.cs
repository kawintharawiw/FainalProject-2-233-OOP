﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace areacalculate
{
    public partial class triangle : Form
    {
        public triangle()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            areacalculateExtension rec = new areacalculateExtension();
            double Width = Convert.ToDouble(txtS.Text);
            double Height = Convert.ToDouble(txtH.Text);
            double result = 0;

            result = rec.Triangleresult(Width, Height);

            triangleresult res = new triangleresult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
