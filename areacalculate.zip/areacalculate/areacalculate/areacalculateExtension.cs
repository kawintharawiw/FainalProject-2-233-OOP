﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace areacalculate
{
    class areacalculateExtension
    {
        double Rectangle, Square, Circular, Triangler;

        public double Rectangleresult(double Width, double Long)
        {
            Rectangle = Width * Long;
            return Rectangle;
        }

        public double Squareresult(double D)
        {
            Square = D * D;
            return Square;
        }

        public double Cirleresult(double R)
        {
            Circular = 3.14 * (R * R);
            return Circular;
        }

        public double Triangleresult(double Height, double Width)
        {
            Triangler = 0.5 * (Height * Width);
            return Triangler;
        }
    }
}
