﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace areacalculate
{
    public partial class circle : Form
    {
        public circle()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            areacalculateExtension circ = new areacalculateExtension();
            double r = Convert.ToInt32(txtR.Text);
            double result = 0;

            result = circ.Cirleresult(r);

            circleresult res = new circleresult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
