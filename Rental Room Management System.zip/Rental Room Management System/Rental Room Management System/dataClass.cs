﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
using Rental_Room_Management_System;

namespace Rental_Room_Management_System
{
    class dataClass : mysql_connection_class
    {
        public List<string> datafill = new List<string>();
        public string search_text;
        private string query = " SELECT * FROM user";

        public DataTable DT = new DataTable();
        private DataSet DS = new DataSet();

        public void Show_Table()
        {
            datafill.Clear();
            MySqlDataReader rd;

            //string query = "SELECT * FROM user";
            using (var cmd = new MySqlCommand())
            {
                connectdb.Open();
                cmd.CommandText = query;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Connection = connectdb;

                datafill.Add("----SELECT FULLNAME----");
                rd = cmd.ExecuteReader();

                while(rd.Read())
                {
                    datafill.Add(rd[1].ToString()); //USERNAME
                }
                connectdb.Close();
            }
        }

        public void Datagrid_data()
        {
            DT.Clear();
            MySqlDataAdapter DA = new MySqlDataAdapter(query, connectdb);
            DA.Fill(DS);
            DT = DS.Tables[0];
        }

        public void filter_data()
        {
            DT.Clear();
            string query_filter = "SELECT * FROM user WHERE username = '" + search_text + "'";
            MySqlDataAdapter DA = new MySqlDataAdapter(query_filter, connectdb);
            DA.Fill(DS);
            DT = DS.Tables[0];
        }

    }
}
