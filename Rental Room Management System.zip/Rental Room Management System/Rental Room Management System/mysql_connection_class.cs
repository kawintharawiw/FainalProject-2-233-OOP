﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace Rental_Room_Management_System
{
    class mysql_connection_class
    {
        public MySqlConnection connectdb;
        public mysql_connection_class()
        {
            string host = "localhost";
            string database = "roommanagement";
            string username = "root";
            string password = "123456";
            string port = "3306";
            string connection_string = "datasource = " + host + ";database = " + database + "; port = " + port
                + ";username =" + username + ";password = " + password + ";SslMode = none;";

            connectdb = new MySqlConnection(connection_string);
        }
    }
}
