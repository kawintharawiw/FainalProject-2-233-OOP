﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.Common;
using MySql.Data;
using Rental_Room_Management_System;

namespace Rental_Room_Management_System
{
    public partial class Emp : Form
    {
        dataClass dc = new dataClass();
        log lo = new log();

        public Emp()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dc.search_text = cmbsearch.Text;

            if (cmbsearch.Text == "-----Select Fullname-----")
            {
                // load all user data
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;
            }
            else
            {
                // show only selected fullname
                dataGridView1.DataSource = null;
                dc.filter_data();
                dataGridView1.DataSource = dc.DT;

            }
        }

        private void Emp_Load(object sender, EventArgs e)
        {
            dc.Show_Table();
            cmbsearch.DataSource = dc.datafill;
            dataGridView1.DataSource = null;
            dc.Datagrid_data();
            dataGridView1.DataSource = dc.DT;

            // pane show/off
            panel1.Visible = false;
            panel2.Visible = false;

            // update and delete fidlds
            txtusername.Enabled = false;
            txtrepassword.Enabled = false;
            txtfullname.Enabled = false;
            txtroomid.Enabled = false;
            txtroomid.Enabled = false;
            txtclassroom.Enabled = false;
            txtphone.Enabled = false;
            txtstatus.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;

            // show datagrid button
            CREATE_DATAGRID_BUTTON();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // show pane1
            panel1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // check password if match
            if (passwordtxt.Text == repasswordtxt.Text)
            {
                // submit
                lo.username = user_fullnametxt.Text;

                lo.user_password = passwordtxt.Text;
                lo.user_fullname = fullnametxt.Text;
                lo.user_roomid = roomidtxt.Text;
                lo.user_classroom = classroomtxt.Text;
                lo.user_phone = phonetxt.Text;
                lo.user_status = statustxt.Text;

                lo.ADD_USER();

                MessageBox.Show("user" + user_fullnametxt.Text + "added to the database successfully!");

                // update datagridview
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;

                // shoud close the pane1 if successfully
                panel1.Visible = false;
            }
            else
            {
                MessageBox.Show("Check your password!");
            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }


        private void cbshowpass_CheckedChanged(object sender, EventArgs e)
        {
            // showing password
            if (cbshowpass.Checked)
            {
                // show
                passwordtxt.UseSystemPasswordChar = false;
                repasswordtxt.UseSystemPasswordChar = false;

            }
            else
            {
                // hide by using password chapacter
                passwordtxt.UseSystemPasswordChar = true;
                repasswordtxt.UseSystemPasswordChar = true;
            }
        }

        private void checkBup_CheckedChanged(object sender, EventArgs e)
        {
            // update chack box
            if (checkBup.Checked)
            {
                txtfullname.Enabled = true;
                txtusername.Enabled = true;
                txtpassword.Enabled = true;
                txtrepassword.Enabled = true;
                btnUpdate.Enabled = true;
            }
            else
            {
                txtfullname.Enabled = false;
                txtusername.Enabled = false;
                txtrepassword.Enabled = false;
                txtpassword.Enabled = false;
                btnUpdate.Enabled = false;
            }
        }

        private string get_fullname;
        private void checkBdel_CheckedChanged(object sender, EventArgs e)
        {
            
            // delete chack box
            if (checkBdel.Checked)
            {
                txtfullname.Text = get_fullname;
                btnDelete.Enabled = true;
            }
            else
            {
                btnDelete.Enabled = false;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             
            // click button
            DataGridView senderGrid = (DataGridView)sender;
            try
            {
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    get_fullname = (dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString());
                    txtfullname.Text = get_fullname;
                    txtusername.Text = (dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString());
                    txtpassword.Text = (dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());
                    txtrepassword.Text = (dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());
                    txtroomid.Text = (dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString());
                    txtclassroom.Text = (dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString());
                    txtphone.Text = (dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString());
                    txtstatus.Text = (dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString());

                    panel2.Visible = true;
                }
            }
            catch
            {
                MessageBox.Show("Dont click the header!");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // for update button
            if (txtusername.Text == txtrepassword.Text)
            {
                // where
                lo._fullname = get_fullname;
                // set
                lo.username = txtusername.Text;
                lo.user_password = txtrepassword.Text;
                lo.user_fullname = txtfullname.Text;
                lo.user_roomid = txtroomid.Text;
                lo.user_classroom = txtclassroom.Text;
                lo.user_phone = txtphone.Text;
                lo.user_status = txtstatus.Text;

                lo.UPDATE_USER();

                // update the datagridview
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;
                // refresh datagrid button
                dataGridView1.Columns.Remove("btncol");

                CREATE_DATAGRID_BUTTON();

                MessageBox.Show("Update Succesfully!");
                panel2.Visible = false;
            }
            else
            {
                MessageBox.Show("Please check you password!");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // delete button
            DialogResult dialog = MessageBox.Show("Are you sure?", "DELETE THIS USER?", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                lo._fullname = get_fullname;

                lo.DELETE_USER();

                // update the datagridview
                dataGridView1.DataSource = null;
                dc.Datagrid_data();
                dataGridView1.DataSource = dc.DT;
                // refresh datagrid button
                dataGridView1.Columns.Remove("btncol");

                CREATE_DATAGRID_BUTTON();

                ////panel2.Visible = false;
                MessageBox.Show("User Delete");
            }
            else
            {

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // close pane1
            panel1.Visible = false;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            // close pane2
            panel2.Visible = false;
        }
        private void CREATE_DATAGRID_BUTTON()
        {
            DataGridViewButtonColumn btn_col = new DataGridViewButtonColumn();
            btn_col.HeaderText = "UPDATE/DELETE";
            btn_col.Text = "Click here";
            btn_col.Name = "btncol";
            btn_col.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(btn_col);
        }
    }
}
