﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace Rental_Room_Management_System
{
    class log : mysql_connection_class
    {
     
        public string username { set; get; }
        public string user_password { set; get; }
        public string user_fullname { set; get; }
        public string user_roomid { set; get; }
        public string user_classroom { set; get; }
        public string user_phone { set; get; }
        public string user_status { set; get; }

        // create properties for where databass get data
        public string _fullname { set; get; }

        public bool Validate_User()
        {
            bool check = false;
            connectdb.Open();
            MySqlDataReader rd;
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = "SELECT * FROM user WHERE username=@user AND user_password=@pass";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;

                //PARAMETERS
                cmd.Parameters.Add("@user", MySqlDbType.VarChar).Value = username;
                cmd.Parameters.Add("@pass", MySqlDbType.VarChar).Value = user_password;

                rd = cmd.ExecuteReader();

                while (rd.Read())
                {
                    check = true;
                    user_fullname = rd.GetString("user_fullname");
                }
                connectdb.Close();
            }
            return check;
        }

        public void ADD_USER()
        {
            connectdb.Open();
            string query = "INSERT INTO user(username,user_password,user_repassword,user_fullname,user_roomid,user_classroom,user_phone,user_status,)Values(@user, @pass,@rpass, @name,@rid,@cr,@pn,@st)";
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;

                cmd.Parameters.Add("@user", MySqlDbType.VarChar).Value = username;
                cmd.Parameters.Add("@pass", MySqlDbType.VarChar).Value = user_password;
                cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = user_fullname;
                cmd.Parameters.Add("@rid", MySqlDbType.VarChar).Value = user_roomid;
                cmd.Parameters.Add("@cr", MySqlDbType.VarChar).Value = user_classroom;
                cmd.Parameters.Add("@ph", MySqlDbType.VarChar).Value = user_phone;
                cmd.Parameters.Add("@st", MySqlDbType.VarChar).Value = user_status;



                cmd.ExecuteNonQuery();
                connectdb.Close();

            }
        }
        public void UPDATE_USER()
        {
            connectdb.Open();
            string query = "UPDATE user SET username=@user, user_password=@pass, user_fullname=@name, user_roomid=@rid user_classroom=@cr,user_phone=@pn,user_status=@st WHERE user_fullname=@fn";
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;
                // WHERE
                cmd.Parameters.Add("@fn", MySqlDbType.VarChar).Value = _fullname;
                // set
                cmd.Parameters.Add("@user", MySqlDbType.VarChar).Value = username;
                cmd.Parameters.Add("@pass", MySqlDbType.VarChar).Value = user_password;
                cmd.Parameters.Add("@name", MySqlDbType.VarChar).Value = user_fullname;
                cmd.Parameters.Add("@rid", MySqlDbType.VarChar).Value = user_roomid;
                cmd.Parameters.Add("@cr", MySqlDbType.VarChar).Value = user_classroom;
                cmd.Parameters.Add("@pn", MySqlDbType.VarChar).Value = user_phone;
                cmd.Parameters.Add("@st", MySqlDbType.VarChar).Value = user_status;

                cmd.ExecuteNonQuery();
                connectdb.Close();
            }
        }

        public void DELETE_USER()
        {
            connectdb.Open();
            string query = "DELETE FROM user WHERE user_fullname=@fn";
            using (var cmd = new MySqlCommand())
            {
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = connectdb;
                // WHERE
                cmd.Parameters.Add("@fn", MySqlDbType.VarChar).Value = _fullname;

                cmd.ExecuteNonQuery();
                connectdb.Close();
            }
        }
    }
}
